#!/bin/bash
python3 ~/Dstairlines/FEV23_Airlines/src/db_update/update_db_with_flights_schedules.py >> ~/Dstairlines/FEV23_Airlines/logs/res_maj_update_db_with_flights_schedules.txt
